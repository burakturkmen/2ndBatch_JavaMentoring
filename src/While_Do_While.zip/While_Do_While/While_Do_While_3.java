package While_Do_While;

public class While_Do_While_3 {
    public static void main(String[] args) {

        //Do while nedir?

        //while
        int i = 10;

        while (i < 5){
            System.out.println("Hello While");
        }

        //do-while
        int a = 10;
        do {
            System.out.println("Hello Do-While");
        }
        while (a < 5);


    }
}
