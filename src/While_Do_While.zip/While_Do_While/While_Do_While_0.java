package While_Do_While;

import java.util.Scanner;

public class While_Do_While_0 {
    public static void main(String[] args) {

        /*
            döngü değişkeni  int, char, long..
            while(koşul){   sayı < 10
            işlem1
            işlem2
            işlem3
            arttırma, azaltma i++; i--;
            }
         */

        int sayi = 0;

        while (sayi < 10){

            sayi++;

            System.out.println("Döngü: " + sayi);
        }


    }
}
